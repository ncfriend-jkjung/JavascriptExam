module.exports = {
  entry: "./widget/index.js",
  devtool: 'source-map'
}